package tpmundial;

public class Encargado {
	
	private int id;
	private String nombre;
	
}
